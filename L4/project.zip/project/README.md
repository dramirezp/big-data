# Create all the required containers.

```bash
docker compose up -d --build
# the output should look like
 ✔ Network project_elastic  Created
 ✔ Container postgres       Started
 ✔ Container bigdatap1      Started
 ✔ Container elasticsearch  Started
 ✔ Container kibana         Started
```

# Make sure Elasticsearch and Kibana are working properly

1. [http://127.0.0.1:5601/app/home#/](http://127.0.0.1:5601/app/home#/)

<p align="center">
  <img src="images/kibana.png" alt="TEC" width="800">
</p>

2. [http://127.0.0.1:9200/](http://127.0.0.1:9200/)

<p align="center">
  <img src="images/elasticsearch.png" alt="TEC" width="400">
</p>


# Load the index templates into Elasticsearch

In Kibana, go to Settings (hamburger menu) → Management → Dev Tools, and execute the following commands:

```json
PUT _index_template/articles_template
{
  "index_patterns": ["articles-*"],
  "template": {
    "settings": {
      "number_of_shards": 1,
      "number_of_replicas": 0
    },
    "mappings": {
      "properties": {
        "category": {
          "type": "keyword"
        },
        "created_date": {
          "type": "date"
        },
        "id": {
          "type": "keyword"
        },
        "type": {
          "type": "keyword"
        },
        "version": {
          "type": "keyword"
        },
        "title": {
          "type": "text",
          "fields": {
            "keyword": {
              "type": "keyword",
              "ignore_above": 256
            }
          }
        },
        "link": {
          "type": "keyword"
        },
        "site": {
          "type": "keyword"
        },
        "abstract": {
          "type": "text"
        },
        "license": {
          "type": "keyword"
        },
        "authors": {
          "type": "nested",
          "properties": {
            "author_inst": {
              "type": "text",
              "fields": {
                "keyword": {
                  "type": "keyword",
                  "ignore_above": 256
                }
              }
            },
            "author_name": {
              "type": "text",
              "fields": {
                "keyword": {
                  "type": "keyword",
                  "ignore_above": 256
                }
              }
            }
          }
        }
      }
    }
  }
}
```

<p align="center">
  <img src="images/articles-index-template.png" alt="TEC" width="800">
</p>



```json
PUT _index_template/vectors_template
{
  "index_patterns": ["vec-*"],
  "template": {
    "settings": {
      "number_of_shards": 1,
      "number_of_replicas": 0
    },
    "mappings": {
      "properties": {
        "category": { "type": "keyword" },
        "created_date": { "type": "date" },
        "id": { "type": "keyword" },
        "type": { "type": "keyword" },
        "version": { "type": "keyword" },
        "title": {
          "type": "text",
          "fields": {
            "keyword": { "type": "keyword", "ignore_above": 256 }
          }
        },
        "link": { "type": "keyword" },
        "site": { "type": "keyword" },
        "abstract": { "type": "text" },
        "license": { "type": "keyword" },
        "text_for_embedding": { "type": "text" },
        "embedding": {
          "type": "dense_vector",
          "dims": 768,
          "index": true,
          "similarity": "cosine"
        },
        "authors": {
          "type": "nested",
          "properties": {
            "author_inst": {
              "type": "text",
              "fields": {
                "keyword": { "type": "keyword", "ignore_above": 256 }
              }
            },
            "author_name": {
              "type": "text",
              "fields": {
                "keyword": { "type": "keyword", "ignore_above": 256 }
              }
            }
          }
        }
      }
    }
  }
}
```

<p align="center">
  <img src="images/vector-index-template.png" alt="TEC" width="800">
</p>

# Connect to the Jupyter Notebook

1. Go to [http://127.0.0.1:8888/](http://127.0.0.1:8888/)
<p align="center">
  <img src="images/jupyter.png" alt="TEC" width="800">
</p>

2. To obtain the authentication token, execute the following command in a terminal:

```bash
docker compose logs -f bigdatap1  

bigdatap1  |     To access the server, open this file in a browser:
bigdatap1  |         file:///root/.local/share/jupyter/runtime/jpserver-1-open.html
bigdatap1  |     Or copy and paste one of these URLs:
bigdatap1  |         http://681839b60ef7:8888/tree?token=58444a6acc4b3c75a3fcbac63aae6005085e2175c1719a81
bigdatap1  |         http://127.0.0.1:8888/tree?token=58444a6acc4b3c75a3fcbac63aae6005085e2175c1719a81
```

Copy the token, for example: **58444a6acc4b3c75a3fcbac63aae6005085e2175c1719a81**

3. Start a session in Jupyter Notebook

4. Go to notebooks and open `P.ipynb` or create a new notebook.