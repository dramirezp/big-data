

```bash
docker compose up --build
```

## Servicios

| Servicio | URL |
|---|---|
| Jupyter | http://localhost:8888 |
| Kafka UI | http://localhost:8080 |
