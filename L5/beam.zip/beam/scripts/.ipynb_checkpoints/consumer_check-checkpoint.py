import json
import os
from kafka import KafkaConsumer

bootstrap = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "kafka:9092")
topic = os.getenv("KAFKA_TOPIC", "video-events")

consumer = KafkaConsumer(
    topic,
    bootstrap_servers=bootstrap,
    auto_offset_reset="earliest",
    enable_auto_commit=True,
    group_id="debug-consumer",
    value_deserializer=lambda v: json.loads(v.decode("utf-8")),
)

print(f"Reading from {topic} on {bootstrap}")
for msg in consumer:
    print(msg.value)
