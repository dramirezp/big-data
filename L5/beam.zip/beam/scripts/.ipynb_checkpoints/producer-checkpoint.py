import json
import os
import random
import time
from datetime import datetime, timedelta, timezone

from kafka import KafkaProducer

bootstrap = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "kafka:9092")
topic = os.getenv("KAFKA_TOPIC", "video-events")

producer = KafkaProducer(
    bootstrap_servers=bootstrap,
    key_serializer=lambda k: k.encode("utf-8"),
    value_serializer=lambda v: json.dumps(v).encode("utf-8"),
)

users = ["annie", "nereo", "norma"]
videos = ["video-A", "video-B"]
ads = ["ad-1", "ad-2"]

print(f"Produciendo eventos en {topic}")
print("Algunos eventos tienen tiempo incorrecto para simular datos tarte")

while True:
    now = datetime.now(timezone.utc)

    # Algunos eventos llegan tarde: el event_time queda en el pasado.
    late_seconds = random.choice([0, 0, 0, 0, 30, 60, 90, 120])
    event_time = now - timedelta(seconds=late_seconds)

    user = random.choice(users)
    event = {
        "user_id": user,
        "video_id": random.choice(videos),
        "ad_id": random.choice(ads),
        "watch_seconds": random.randint(1, 20),
        "event_time": event_time.isoformat(),
        "processing_time_hint": now.isoformat(),
        "is_late_simulated": late_seconds > 0,
        "late_by_seconds": late_seconds,
    }

    producer.send(topic, key=user, value=event)
    producer.flush()

    print(event)
    time.sleep(1)
