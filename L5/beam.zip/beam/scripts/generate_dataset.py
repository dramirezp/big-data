import csv
import random
from datetime import datetime, timedelta, timezone

users = ["annie", "nereo", "norma", "sofia", "matias"]
videos = ["video-A", "video-B", "video-C"]

start = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)

with open("large_video_events.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["user_id", "video_id", "watch_seconds", "event_time"])

    for i in range(100000):
        event_time = start + timedelta(seconds=random.randint(0, 3600))

        writer.writerow([
            random.choice(users),
            random.choice(videos),
            random.randint(1, 30),
            event_time.isoformat()
        ])