import argparse
import json
from datetime import datetime

import apache_beam as beam
from apache_beam.io.kafka import ReadFromKafka
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from apache_beam.transforms import window
from apache_beam.transforms.trigger import (
    AfterWatermark,
    AfterProcessingTime,
    AccumulationMode,
)


class AddEventTimestamp(beam.DoFn):
    def process(self, record):
        key, value = record
        event = json.loads(value.decode("utf-8"))

        event_ts = datetime.fromisoformat(event["event_time"]).timestamp()

        user_id = event["user_id"]
        watch_seconds = int(event["watch_seconds"])

        yield beam.window.TimestampedValue(
            (user_id, watch_seconds),
            event_ts
        )


class PrintWindowResult(beam.DoFn):
    def process(
        self,
        element,
        window=beam.DoFn.WindowParam,
        pane_info=beam.DoFn.PaneInfoParam,
    ):
        user_id, total_watch_seconds = element

        print(
            f"user={user_id}, "
            f"total_watch_seconds={total_watch_seconds}, "
            f"window_start={window.start.to_utc_datetime()}, "
            f"window_end={window.end.to_utc_datetime()}, "
            f"pane={pane_info}"
        )

        yield element


def get_window(window_type):
    if window_type == "fixed":
        return window.FixedWindows(10)

    if window_type == "sliding":
        return window.SlidingWindows(size=20, period=5)

    if window_type == "session":
        return window.Sessions(10)

    raise ValueError(f"Invalid window type: {window_type}")


def get_accumulation_mode(mode):
    if mode == "discarding":
        return AccumulationMode.DISCARDING

    if mode == "accumulating":
        return AccumulationMode.ACCUMULATING

    if mode == "retracting":
        if hasattr(AccumulationMode, "ACCUMULATING_AND_RETRACTING"):
            return AccumulationMode.ACCUMULATING_AND_RETRACTING

        raise ValueError(
            "ACCUMULATING_AND_RETRACTING is not available in this Beam Python SDK/runtime. "
            "Use discarding or accumulating, or test retracting behavior with a runner/SDK that supports it."
        )

    raise ValueError(f"Invalid accumulation mode: {mode}")


def run(args):
    options = PipelineOptions([
        "--runner=DirectRunner",
        "--direct_running_mode=in_memory",
        "--direct_num_workers=1",
    ])
    options.view_as(StandardOptions).streaming = True

    window_fn = get_window(args.window_type)
    accumulation_mode = get_accumulation_mode(args.accumulation_mode)

    print("=" * 100)
    print(f"Window type: {args.window_type}")
    print(f"Accumulation mode: {args.accumulation_mode}")
    print(f"Kafka bootstrap: {args.bootstrap}")
    print(f"Kafka topic: {args.topic}")
    print("=" * 100)

    with beam.Pipeline(options=options) as p:
        (
            p
            | "ReadFromKafka" >> ReadFromKafka(
                consumer_config={
                    "bootstrap.servers": args.bootstrap,
                    "group.id": f"{args.window_type}-{args.accumulation_mode}-group",
                    "auto.offset.reset": "latest",
                },
                topics=[args.topic],
                expansion_service="localhost:8097",
            )
            | "AssignEventTime" >> beam.ParDo(AddEventTimestamp())
            | "ApplyWindow" >> beam.WindowInto(
                window_fn,
                trigger=AfterWatermark(
                    early=AfterProcessingTime(5),
                    late=AfterProcessingTime(5),
                ),
                allowed_lateness=20,
                accumulation_mode=accumulation_mode,
            )
            | "SumPerUser" >> beam.CombinePerKey(sum)
            | "PrintResults" >> beam.ParDo(PrintWindowResult())
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument("--bootstrap", default="kafka:9092")
    parser.add_argument("--topic", default="video-events")

    parser.add_argument(
        "--window-type",
        choices=["fixed", "sliding", "session"],
        required=True,
    )

    parser.add_argument(
        "--accumulation-mode",
        choices=["discarding", "accumulating", "retracting"],
        required=True,
    )

    args = parser.parse_args()
    run(args)