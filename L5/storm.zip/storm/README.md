# 🌩️ Apache Storm

## Quick Start

```bash
docker compose up -d

# Jupyter http://localhost:8888
# Storm http://localhost:8080
```

## Submit the Real Topology

```bash
docker exec -it storm-nimbus bash
apt-get update && apt-get install -y python3 python3-pip
pip3 install streamparse
pip install streamparse
cd /topology
python word_count.py 
```


```bash
docker compose down
docker compose down -v
```
