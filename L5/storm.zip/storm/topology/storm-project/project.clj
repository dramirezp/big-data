(defproject wordcount "0.0.1-SNAPSHOT"
  :description "WordCount topology — Apache Storm + streamparse"
  :license {:name "Eclipse Public License"
            :url  "http://www.eclipse.org/legal/epl-v10.html"}
  :dependencies [[org.apache.storm/storm-core "2.4.0"]
                 [org.apache.storm/storm-multilang-python "2.4.0"]]
  :main ^:skip-aot wordcount.core
  :profiles {:uberjar {:aot :all}})
