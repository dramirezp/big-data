#!/bin/bash
# =============================================================
#  setup_and_submit.sh
#  Instala dependencias y somete la topology al cluster Storm
#  Correr desde DENTRO del contenedor storm-nimbus:
#    docker exec -it storm-nimbus bash
#    bash /topology/storm-project/setup_and_submit.sh
# =============================================================

set -e

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Storm WordCount — Setup & Submit"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── 1. Dependencias del sistema ───────────────────────────────
echo "[1/5] Instalando dependencias del sistema..."
apt-get update -qq
apt-get install -y -qq python3 python3-pip curl wget leiningen

# ── 2. Dependencias Python ────────────────────────────────────
echo "[2/5] Instalando streamparse..."
pip3 install -q streamparse

# ── 3. Verificar cluster ──────────────────────────────────────
echo "[3/5] Verificando conectividad con Zookeeper y Nimbus..."
storm list && echo "✓ Nimbus accesible"

# ── 4. Copiar proyecto al directorio de trabajo ───────────────
echo "[4/5] Preparando proyecto sparse..."
cp -r /topology/storm-project /tmp/wordcount-project
cd /tmp/wordcount-project

# ── 5. Someter al cluster ─────────────────────────────────────
echo "[5/5] Sometiendo topology al cluster Storm..."
export LEIN_ROOT=1
sparse run -n wordcount -e local

echo ""
echo "✓ Topology sometida. Abre http://localhost:8080 para monitorear."
