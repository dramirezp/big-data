#!/usr/bin/env python3


import random
import time
import threading
from collections import defaultdict
from queue import Queue

from streamparse import Spout, Bolt, Topology
from streamparse.dsl.stream import Grouping


class SentenceSpout(Spout):
    outputs = ["sentence"]

    SENTENCES = [
        "the quick brown fox jumps over the lazy dog",
        "big data is changing the world of technology",
        "apache storm processes millions of tuples per second",
        "real time stream processing is powerful and fast",
        "hadoop and spark batch process large datasets",
        "data pipelines connect producers and consumers",
        "machine learning models need large amounts of data",
        "cloud computing enables scalable data processing",
    ]

    def initialize(self, stormconf, context):
        self.log("SentenceSpout initialized ✓")
        self._count = 0

    def next_tuple(self):
        sentence = random.choice(self.SENTENCES)
        self.emit([sentence])
        self._count += 1
        if self._count % 10 == 0:
            self.log(f"Emitted {self._count} sentences so far")
        time.sleep(0.5)

    def ack(self, tup_id):
        pass

    def fail(self, tup_id):
        self.log(f"Tuple {tup_id} failed — would replay here")


class SplitterBolt(Bolt):
    outputs = ["word"]

    def process(self, tup):
        sentence = tup.values[0]
        for word in sentence.lower().split():
            self.emit([word])



class CounterBolt(Bolt):
    outputs = []

    def initialize(self, conf, ctx):
        self.counts = defaultdict(int)
        self._tuples = 0

    def process(self, tup):
        word = tup.values[0]
        self.counts[word] += 1
        self._tuples += 1

        if self._tuples % 20 == 0:
            top = sorted(self.counts.items(), key=lambda x: x[1], reverse=True)[:10]
            self.log("── Top-10 words ─────────────────────────")
            for rank, (w, c) in enumerate(top, 1):
                self.log(f"  {rank:>2}. {w:<20} {c}")
            self.log("─────────────────────────────────────────")



class WordCountTopology(Topology):
    sentence_spout = SentenceSpout.spec(par=1)

    splitter = SplitterBolt.spec(
        inputs={sentence_spout: Grouping.SHUFFLE},
        par=2,
    )

    counter = CounterBolt.spec(
        inputs={splitter: Grouping.fields("word")},
        par=2,
    )



if __name__ == "__main__":

    print("=" * 50)
    print("  WordCount Topology")
    print("  Corriendo por 60 segundos...")
    print("  Ctrl+C para detener antes")
    print("=" * 50)

    sentence_queue = Queue()
    word_queue = Queue()


    spout    = SentenceSpout()
    splitter = SplitterBolt()
    counter  = CounterBolt()


    spout.emit    = lambda values, **kw: sentence_queue.put(values[0])
    splitter.emit = lambda values, **kw: word_queue.put(values[0])

    spout.log    = lambda msg: print(f"[SPOUT]    {msg}")
    splitter.log = lambda msg: print(f"[SPLIT]    {msg}")
    counter.log  = lambda msg: print(f"[COUNTER]  {msg}")


    spout.initialize({}, {})
    splitter.initialize({}, {})
    counter.initialize({}, {})


    def run_spout():
        while True:
            spout.next_tuple()

    def run_splitter():
        while True:
            sentence = sentence_queue.get()
            class FakeTup:
                values = [sentence]
            splitter.process(FakeTup())

    def run_counter():
        while True:
            word = word_queue.get()
            class FakeTup:
                values = [word]
            counter.process(FakeTup())


    for fn in [run_spout, run_splitter, run_counter]:
        t = threading.Thread(target=fn, daemon=True)
        t.start()


    try:
        time.sleep(60)
    except KeyboardInterrupt:
        print("\nDetenido por el usuario.")

    print("\nTopology finalizada.")
