# Apache Flink

### 1. Start the cluster

```bash
docker compose down
docker compose build
docker compose up -d
```

```bash
docker compose ps
```

Open the **Flink Web UI** at: http://localhost:8081

---

### 2. Verify events are flowing into Kafka

```bash
docker exec kafka \
  /opt/kafka/bin/kafka-console-consumer.sh \
  --bootstrap-server localhost:9092 \
  --topic click-events \
  --from-beginning \
  --max-messages 10
```
---

### 3. Run the SQL job

```bash
docker compose exec jobmanager ./bin/sql-client.sh
docker logs -f flink-taskmanager
```

---

### 4. Run the Java DataStream job


```bash
cd flink-job
mvn clean package -q
cd ..
```


```bash
docker cp flink-job/target/flink-click-analytics-1.0-SNAPSHOT.jar \
  flink-jobmanager:/opt/flink-click-analytics.jar

docker exec flink-jobmanager mkdir -p /tmp/flink-checkpoints
docker exec flink-taskmanager mkdir -p /tmp/flink-checkpoints

docker exec flink-jobmanager \
  flink run \
  -c com.example.ClickAnalyticsJob \
  /opt/flink-click-analytics.jar
```

```bash
docker logs -f flink-taskmanager
```

```bash
docker compose down -v
```
