
CREATE TABLE click_events (
    `user`  STRING,
    page    STRING,
    ts      STRING,
    event_time AS TO_TIMESTAMP(ts, 'yyyy-MM-dd''T''HH:mm:ss''Z'''),
    WATERMARK FOR event_time AS event_time - INTERVAL '5' SECOND
) WITH (
    'connector'                     = 'kafka',
    'topic'                         = 'click-events',
    'properties.bootstrap.servers'  = 'kafka:9092',
    'properties.group.id'           = 'flink-demo',
    'scan.startup.mode'             = 'earliest-offset',
    'format'                        = 'json'
);


CREATE TABLE page_stats_sink (
    window_start    TIMESTAMP(3),
    window_end      TIMESTAMP(3),
    page            STRING,
    click_count     BIGINT,
    unique_users    BIGINT
) WITH (
    'connector' = 'print'
);


INSERT INTO page_stats_sink
SELECT
    TUMBLE_START(event_time, INTERVAL '30' SECOND) AS window_start,
    TUMBLE_END  (event_time, INTERVAL '30' SECOND) AS window_end,
    page,
    COUNT(*)                                        AS click_count,
    COUNT(DISTINCT `user`)                          AS unique_users
FROM click_events
GROUP BY
    TUMBLE(event_time, INTERVAL '30' SECOND),
    page;
