package com.example;

import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.JsonNode;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;

import java.time.Duration;


public class ClickAnalyticsJob {

    public static void main(String[] args) throws Exception {

        final StreamExecutionEnvironment env =
                StreamExecutionEnvironment.getExecutionEnvironment();

        env.setParallelism(2);
        //env.enableCheckpointing(30_000);

        KafkaSource<String> source = KafkaSource.<String>builder()
                .setBootstrapServers("kafka:9092")
                .setTopics("click-events")
                .setGroupId("flink-datastream-demo")
                .setStartingOffsets(OffsetsInitializer.earliest())
                .setValueOnlyDeserializer(new SimpleStringSchema())
                .build();

        DataStream<String> rawStream = env.fromSource(
                source,
                WatermarkStrategy.forBoundedOutOfOrderness(Duration.ofSeconds(5)),
                "Kafka click-events" // nombre del operador
        );


        ObjectMapper mapper = new ObjectMapper();

        DataStream<Tuple2<String, Integer>> pageClicks = rawStream
                .map(json -> {
                    try {
                        JsonNode node = mapper.readTree(json);
                        String page = node.get("page").asText("/unknown");
                        return Tuple2.of(page, 1);
                    } catch (Exception e) {
                        return Tuple2.<String, Integer>of("/parse-error", 1);
                    }
                })
                .returns(Types.TUPLE(Types.STRING, Types.INT))
                .name("Parse JSON");

        DataStream<Tuple2<String, Integer>> windowedCounts = pageClicks
                .keyBy(t -> t.f0, TypeInformation.of(String.class))
                .window(TumblingProcessingTimeWindows.of(Time.seconds(30)))
                .sum(1)
                .name("30s window count");


        windowedCounts
                .map(t -> String.format("[WINDOW] page=%-12s  clicks=%d", t.f0, t.f1))
                .returns(Types.STRING)
                .name("Format output")
                .print();

        env.execute("Click Analytics — 30s Tumbling Window");
    }
}