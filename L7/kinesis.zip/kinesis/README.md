```bash
docker compose up -d
docker compose logs -f
```

```bash

python3 -m venv ~/Documents/kinesis-env

source ~/Documents/kinesis-env/bin/activate

pip install  faker boto3
```

```bash
python3 basic.py
python3 batch.py
python3 ordering.py
python3 multi_consumer.py
```