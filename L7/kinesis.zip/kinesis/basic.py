import sys
import time
import json
import random
import threading
import argparse
from functions import (
    get_client, create_stream, delete_stream, list_shards,
    generate_event, put_record, put_records_batch,
    consume_shard, consume_all_shards,
    get_shard_iterator, read_shard, which_shard,
)

def demo_basic():
    print(f"\n{'═'*60}")
    print("  PATTERN 1: BASIC PRODUCER / CONSUMER")
    print(f"{'═'*60}\n")

    client      = get_client()
    stream_name = "basic-demo"
    create_stream(client, stream_name, shard_count=3)
    shards = list_shards(client, stream_name)

    print("\n  [producer] Writing 15 records...\n")
    sensors = ["sensor-AAA", "sensor-BBB", "sensor-CCC",
               "sensor-DDD", "sensor-EEE"]

    for i in range(15):
        event = generate_event(sensor_id=random.choice(sensors))
        resp  = put_record(client, stream_name, event,
                           partition_key=event["sensor_id"])
        shard = resp["ShardId"]
        seq   = resp["SequenceNumber"][:16]
        print(f"    [PUT] {event['sensor_id']} → {shard} "
              f"| seq={seq}... | status={event['status']}")
        time.sleep(0.1)

    print(f"\n  [consumer] Reading from all shards (TRIM_HORIZON)...\n")
    lock    = threading.Lock()
    counter = {"n": 0}

    def on_record(event, raw):
        with lock:
            counter["n"] += 1
            print(f"    [GET] #{counter['n']:02d} shard={raw['ShardId'][-4:]} "
                  f"seq={raw['SequenceNumber'][:16]}... "
                  f"| {event['sensor_id']} | {event['event_type']} "
                  f"| {event['value']} | {event['status']}")

    consume_all_shards(client, stream_name, on_record, duration=8)
    print(f"\n  Total records read: {counter['n']}")

def main():
    demo_basic()

if __name__ == "__main__":
    main()