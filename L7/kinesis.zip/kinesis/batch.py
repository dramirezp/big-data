import sys
import time
import json
import random
import threading
import argparse
from functions import (
    get_client, create_stream, delete_stream, list_shards,
    generate_event, put_record, put_records_batch,
    consume_shard, consume_all_shards,
    get_shard_iterator, read_shard, which_shard,
)

def demo_batch():

    print(f"\n{'═'*60}")
    print("  PATTERN 3: BATCH WRITES (PutRecords)")
    print(f"{'═'*60}\n")

    client      = get_client()
    stream_name = "batch-demo"
    create_stream(client, stream_name, shard_count=3)

    msg_count = 100
    events    = [generate_event() for _ in range(msg_count)]

    print(f"  Sending {msg_count} records one-by-one...")
    t0 = time.time()
    for e in events[:20]:
        put_record(client, stream_name, e, partition_key=e["sensor_id"])
    single_time = time.time() - t0
    print(f"    20 single puts: {single_time:.3f}s  "
          f"({20/single_time:.0f} records/sec)")

    print(f"\n  Sending {msg_count} records in one PutRecords batch...")
    t0      = time.time()
    result  = put_records_batch(client, stream_name, events)
    batch_time = time.time() - t0
    print(f"    {msg_count} batch puts: {batch_time:.3f}s  "
          f"({msg_count/batch_time:.0f} records/sec)")
    print(f"    Succeeded: {result['succeeded']}  "
          f"Failed: {result['failed']}")

    speedup = (single_time / 20) * msg_count / batch_time
    print(f"\n  Estimated speedup for {msg_count} records: ~{speedup:.1f}x")

    print(f"\n  [consumer] Reading back all records...\n")
    lock    = threading.Lock()
    counter = {"n": 0}

    shard_counts = {}

    def on_record(event, raw):
        shard = raw["ShardId"]
        with lock:
            counter["n"] += 1
            shard_counts[shard] = shard_counts.get(shard, 0) + 1

    consume_all_shards(client, stream_name, on_record, duration=8)

    print(f"  Total records read: {counter['n']}")
    print(f"\n  Distribution across shards:")
    for shard_id, count in sorted(shard_counts.items()):
        bar = "#" * count
        print(f"    {shard_id[-6:]}: {count:4d}  {bar[:50]}")

def main():
    demo_batch()

if __name__ == "__main__":
    main()