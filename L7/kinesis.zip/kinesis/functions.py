import json
import time
import hashlib
import random
import uuid
import threading
from datetime import datetime, timezone

import boto3
from botocore.exceptions import ClientError

from faker import Faker
fake = Faker()


LOCALSTACK_ENDPOINT = "http://localhost:4566"
AWS_REGION          = "us-east-1"


_BOTO_KWARGS = dict(
    endpoint_url         = LOCALSTACK_ENDPOINT,
    region_name          = AWS_REGION,
    aws_access_key_id    = "test",
    aws_secret_access_key= "test",
)

def get_client():
    return boto3.client("kinesis", **_BOTO_KWARGS)


def create_stream(client, stream_name: str, shard_count: int = 3):
    try:
        client.create_stream(StreamName=stream_name, ShardCount=shard_count)
    except ClientError as e:
        if e.response["Error"]["Code"] == "ResourceInUseException":
            print(f"  [setup] Stream '{stream_name}' already exists")
            return
        raise

    waiter = client.get_waiter("stream_exists")
    waiter.wait(StreamName=stream_name)


def delete_stream(client, stream_name: str):
    try:
        client.delete_stream(StreamName=stream_name)
    except ClientError:
        pass


def describe_stream(client, stream_name: str) -> dict:
    resp = client.describe_stream(StreamName=stream_name)
    return resp["StreamDescription"]


def list_shards(client, stream_name: str) -> list:
    resp = client.list_shards(StreamName=stream_name)
    return resp["Shards"]

def partition_key_to_hash(key: str) -> int:
    return int(hashlib.md5(key.encode()).hexdigest(), 16)


def which_shard(key: str, shards: list) -> str:
    h = partition_key_to_hash(key)
    for shard in shards:
        start = int(shard["HashKeyRange"]["StartingHashKey"])
        end   = int(shard["HashKeyRange"]["EndingHashKey"])
        if start <= h <= end:
            return shard["ShardId"]
    return shards[-1]["ShardId"]


def generate_event(sensor_id: str = None, event_type: str = None) -> dict:
    types = ["temperature", "humidity", "pressure", "vibration"]
    return {
        "event_id":   str(fake.uuid4()),
        "timestamp":  datetime.now(timezone.utc).isoformat(),
        "sensor_id":  sensor_id or f"sensor-{fake.bothify('??###')}",
        "location":   fake.city(),
        "event_type": event_type or fake.random_element(types),
        "value":      round(fake.pyfloat(min_value=0, max_value=100), 2),
        "status":     fake.random_element(["OK", "OK", "OK", "WARN", "ALERT"]),
    }

def put_record(client, stream_name: str, event: dict,
               partition_key: str = None) -> dict:

    key     = partition_key or event.get("sensor_id", str(uuid.uuid4()))
    payload = json.dumps(event).encode("utf-8")

    resp = client.put_record(
        StreamName    = stream_name,
        Data          = payload,
        PartitionKey  = key,
    )
    return resp 


def put_records_batch(client, stream_name: str,
                      events: list, partition_key_fn=None) -> dict:
    if partition_key_fn is None:
        partition_key_fn = lambda e: e.get("sensor_id", str(uuid.uuid4()))

    records = [
        {
            "Data":         json.dumps(e).encode("utf-8"),
            "PartitionKey": partition_key_fn(e),
        }
        for e in events
    ]

    resp      = client.put_records(StreamName=stream_name, Records=records)
    failed    = resp["FailedRecordCount"]
    succeeded = len(records) - failed
    return {"succeeded": succeeded, "failed": failed, "response": resp}


def get_shard_iterator(client, stream_name: str, shard_id: str,
                       iterator_type: str = "TRIM_HORIZON") -> str:
    resp = client.get_shard_iterator(
        StreamName        = stream_name,
        ShardId           = shard_id,
        ShardIteratorType = iterator_type,
    )
    return resp["ShardIterator"]


def read_shard(client, iterator: str, limit: int = 100) -> tuple[list, str]:
    resp          = client.get_records(ShardIterator=iterator, Limit=limit)
    records       = resp["Records"]
    next_iterator = resp.get("NextShardIterator")
    return records, next_iterator


def consume_shard(client, stream_name: str, shard_id: str,
                  callback, duration: int = 15,
                  iterator_type: str = "TRIM_HORIZON"):
    iterator  = get_shard_iterator(client, stream_name, shard_id, iterator_type)
    deadline  = time.time() + duration

    while time.time() < deadline and iterator:
        records, iterator = read_shard(client, iterator)
        for raw in records:
            try:
                raw["ShardId"] = shard_id 
                event = json.loads(raw["Data"].decode("utf-8"))
                callback(event, raw)
            except Exception as e:
                print(f"  [consumer] decode error: {e}")
        if not records:
            time.sleep(0.2)   # no records — back off before next poll


def consume_all_shards(client, stream_name: str, callback,
                       duration: int = 15,
                       iterator_type: str = "TRIM_HORIZON"):
    shards  = list_shards(client, stream_name)
    threads = []
    for shard in shards:
        t = threading.Thread(
            target = consume_shard,
            args   = (client, stream_name, shard["ShardId"],
                      callback, duration, iterator_type),
            daemon = True,
        )
        threads.append(t)
        t.start()
    for t in threads:
        t.join()
