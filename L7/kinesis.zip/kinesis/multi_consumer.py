import sys
import time
import json
import random
import threading
import argparse
from functions import (
    get_client, create_stream, delete_stream, list_shards,
    generate_event, put_record, put_records_batch,
    consume_shard, consume_all_shards,
    get_shard_iterator, read_shard, which_shard,
)

def demo_multi_consumer():
    print(f"\n{'═'*60}")
    print("  PATTERN 4: MULTIPLE INDEPENDENT CONSUMERS")
    print(f"{'═'*60}\n")

    client      = get_client()
    stream_name = "multi-consumer-demo"
    create_stream(client, stream_name, shard_count=2)

    lock      = threading.Lock()
    results   = {"analytics": [], "alerts": [], "replay": []}

    def analytics_consumer():
        def on_record(event, raw):
            with lock:
                results["analytics"].append(event["sensor_id"])
                print(f"  [ANALYTICS] {event['sensor_id']} | "
                      f"{event['event_type']} | {event['value']:.1f}")
        consume_all_shards(client, stream_name, on_record, duration=12,
                           iterator_type="TRIM_HORIZON")

    def alerts_consumer():
        def on_record(event, raw):
            if event.get("status") == "ALERT":
                with lock:
                    results["alerts"].append(event["sensor_id"])
                    print(f"  [ALERTS]    *** ALERT *** {event['sensor_id']} "
                          f"| value={event['value']:.1f}")
        consume_all_shards(client, stream_name, on_record, duration=12,
                           iterator_type="TRIM_HORIZON")

    def replay_consumer():
        time.sleep(6) 
        print(f"\n  [REPLAY] Starting late — replaying from TRIM_HORIZON...\n")
        def on_record(event, raw):
            with lock:
                results["replay"].append(event["sensor_id"])
                print(f"  [REPLAY]    {event['sensor_id']} seq="
                      f"{raw['SequenceNumber'][:12]}...")
        consume_all_shards(client, stream_name, on_record, duration=8,
                           iterator_type="TRIM_HORIZON")

    print("  Starting 3 independent consumers...\n")
    threads = [
        threading.Thread(target=analytics_consumer, daemon=True),
        threading.Thread(target=alerts_consumer,    daemon=True),
        threading.Thread(target=replay_consumer,    daemon=True),
    ]
    for t in threads:
        t.start()

    time.sleep(1)

    print("  [producer] Writing 20 records...\n")
    for _ in range(20):
        event = generate_event()
        put_record(client, stream_name, event,
                   partition_key=event["sensor_id"])
        time.sleep(0.3)

    print("\n  Waiting for consumers to finish...")
    for t in threads:
        t.join()

    print(f"\n{'─'*60}")
    print(f"  RESULTS:")
    print(f"    Analytics consumer read: {len(results['analytics'])} records")
    print(f"    Alerts consumer flagged: {len(results['alerts'])} ALERTs")
    print(f"    Replay consumer read:    {len(results['replay'])} records "
          f"(started late, still got all records)")
    print(f"{'─'*60}")


def main():
    demo_multi_consumer()

if __name__ == "__main__":
    main()