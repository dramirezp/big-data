import sys
import time
import json
import random
import threading
import argparse
from functions import (
    get_client, create_stream, delete_stream, list_shards,
    generate_event, put_record, put_records_batch,
    consume_shard, consume_all_shards,
    get_shard_iterator, read_shard, which_shard,
)

def demo_ordering():

    print(f"\n{'═'*60}")
    print("  PATTERN 2: ORDERING PER PARTITION KEY")
    print(f"{'═'*60}\n")

    client      = get_client()
    stream_name = "ordering-demo"
    create_stream(client, stream_name, shard_count=3)
    shards = list_shards(client, stream_name)

    sensors = ["sensor-AAA", "sensor-BBB", "sensor-CCC"]


    for s in sensors:
        sid = which_shard(s, shards)
        print(f"    {s} → {sid}")
    print()

    futures = []
    for seq in range(1, 6):
        for sensor in sensors:
            event = generate_event(sensor_id=sensor)
            event["seq"] = seq
            resp  = put_record(client, stream_name, event,
                               partition_key=sensor)
            print(f"    [PUT] {sensor} seq={seq} → {resp['ShardId']}")
            futures.append((sensor, seq, resp["ShardId"]))
        time.sleep(0.05)

    print(f"\n  [consumer] Verifying delivery order per sensor...\n")
    lock  = threading.Lock()
    seen  = {}
    total = {"ok": 0, "bad": 0}

    def on_record(event, raw):
        sensor = event.get("sensor_id", "?")
        seq    = event.get("seq", 0)
        with lock:
            last = seen.get(sensor, 0)
            if seq == last + 1:
                verdict = "OK ORDER"
                total["ok"] += 1
            else:
                verdict = f"OUT OF ORDER (expected {last+1})"
                total["bad"] += 1
            seen[sensor] = seq
            print(f"    [{sensor}] seq={seq}  {verdict}")

    consume_all_shards(client, stream_name, on_record, duration=8)

    print(f"\n  Results: {total['ok']} in-order, {total['bad']} out-of-order")

def main():
    demo_ordering()

if __name__ == "__main__":
    main()