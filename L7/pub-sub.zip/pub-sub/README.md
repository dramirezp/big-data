```bash
docker run --rm -p 8085:8085 \
  --platform linux/amd64 \
  google/cloud-sdk:latest \
  gcloud beta emulators pubsub start \
  --host-port=0.0.0.0:8085 --project=demo-project
```

```bash

python3 -m venv ~/Documents/pubsub-env

source ~/Documents/pubsub-env/bin/activate

pip install google-cloud-pubsub faker
```

```bash

python3 competing_consumers.py
python3 ordering.py
python3 filtering.py
python3 broadcast.py
```