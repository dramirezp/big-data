import os
import sys
import json
import time
import random
import uuid
import argparse
import threading
from datetime import datetime, timezone
from concurrent.futures import TimeoutError
from functions import *
from google.cloud import pubsub_v1
from google.api_core.exceptions import AlreadyExists
from google.cloud import pubsub_v1
from google.api_core.exceptions import AlreadyExists
from faker import Faker

PROJECT_ID    = "my-bigdata-project" 
TOPIC_NAME    = "bigdata-demo"
EMULATOR_HOST = "localhost:8085"

def demo_broadcast(project_id: str, msg_count: int = 10):
    print(f"\n{'═'*60}")
    print("  PATTERN 2: BROADCAST (fan-out)")
    print(f"{'═'*60}")

    publisher  = make_publisher()
    subscriber = pubsub_v1.SubscriberClient()

    topic_path = setup_topic(publisher, project_id, "broadcast-demo")

    services = ["analytics", "alerting", "storage"]
    sub_paths = {}
    for svc in services:
        sub_paths[svc] = setup_subscription(
            subscriber, project_id, topic_path, f"broadcast-{svc}-sub"
        )
    print()

    events = [generate_event() for _ in range(msg_count)]
    ok = publish_messages_no_order(publisher, topic_path, events)
    print(f"\n  [producer] Published {ok}/{msg_count} messages\n")
    time.sleep(1)

    lock   = threading.Lock()
    totals = {svc: {"count": 0} for svc in services}

    threads = []
    for svc in services:
        cb = make_callback(svc.upper(), totals[svc], lock)
        t  = threading.Thread(
            target=stream_subscription,
            args=(subscriber, sub_paths[svc], cb, 10, svc),
            daemon=True,
        )
        threads.append(t)

    print("  Starting 3 independent consumers on diferent subscriptions...\n")
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    print(f"\n{'─'*60}")
    print("  RESULTS — every service got every message:")
    for svc, c in totals.items():
        bar = "#" * c["count"]
        print(f"    {svc:12s}: {c['count']:3d} messages  {bar}")
    print(f"{'─'*60}\n")

def main():
    os.environ["PUBSUB_EMULATOR_HOST"] = EMULATOR_HOST
    project_id = "demo-project"
    msg_count = 20
    demo_broadcast(project_id, msg_count)

if __name__ == "__main__":
    main()
