import os
import sys
import json
import time
import random
import uuid
import argparse
import threading
from datetime import datetime, timezone
from concurrent.futures import TimeoutError
from functions import *
from google.cloud import pubsub_v1
from google.api_core.exceptions import AlreadyExists
from google.cloud import pubsub_v1
from google.api_core.exceptions import AlreadyExists
from faker import Faker

PROJECT_ID    = "my-bigdata-project" 
TOPIC_NAME    = "bigdata-demo"
EMULATOR_HOST = "localhost:8085"


def demo_competing_consumers(project_id: str, msg_count: int = 20):
    print(f"\n{'═'*60}")
    print("  PATTERN 1: COMPETING CONSUMERS (load balancing)")
    print(f"{'═'*60}")

    publisher  = make_publisher()
    subscriber = pubsub_v1.SubscriberClient()

    topic_path = setup_topic(publisher, project_id, "competing-demo")
    sub_path   = setup_subscription(subscriber, project_id, topic_path,
                                    "competing-demo-sub")
    print()



    lock    = threading.Lock()
    totals  = {"Worker-A": {"count": 0},
                "Worker-B": {"count": 0},
                "Worker-C": {"count": 0}}

    threads = []
    for name in totals:
        slow = (name == "Worker-C")
        cb   = make_callback(name, totals[name], lock, slow=slow)
        t    = threading.Thread(
            target=stream_subscription,
            args=(subscriber, sub_path, cb, 12, name),
            daemon=True,
        )
        threads.append(t)

    print("  Starting 3 competing workers on the SAME subscription...\n")

    for t in threads:
        t.start()

    time.sleep(2)

    events = [generate_event() for _ in range(msg_count)]
    ok = publish_messages_no_order(publisher, topic_path, events)
    print(f"\n  [producer] Published {ok}/{msg_count} messages\n")


    for t in threads:
        t.join()

    print(f"\n{'─'*60}")
    print("  RESULTS — message distribution across workers:")
    for name, c in totals.items():
        bar = "#" * c["count"]
        print(f"    {name}: {c['count']:3d} messages  {bar}")
    total = sum(c["count"] for c in totals.values())
    print(f"    Total received: {total}/{msg_count}")
    print(f"{'─'*60}\n")




def main():
    os.environ["PUBSUB_EMULATOR_HOST"] = EMULATOR_HOST
    project_id = "demo-project"
    msg_count = 200
    demo_competing_consumers(project_id, msg_count)

if __name__ == "__main__":
    main()
