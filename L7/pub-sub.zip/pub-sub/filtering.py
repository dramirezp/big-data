import os
import sys
import json
import time
import random
import uuid
import argparse
import threading
from datetime import datetime, timezone
from concurrent.futures import TimeoutError
from functions import *
from google.cloud import pubsub_v1
from google.api_core.exceptions import AlreadyExists
from google.cloud import pubsub_v1
from google.api_core.exceptions import AlreadyExists
from faker import Faker

PROJECT_ID    = "my-bigdata-project" 
TOPIC_NAME    = "bigdata-demo"
EMULATOR_HOST = "localhost:8085"


def demo_filtering(project_id: str, msg_count: int = 30):
    print(f"\n{'═'*60}")
    print("  PATTERN 4: SUBSCRIPTION FILTERING")
    print(f"{'═'*60}")

    publisher  = make_publisher()
    subscriber = pubsub_v1.SubscriberClient()

    topic_path = setup_topic(publisher, project_id, "filter-demo")

    subs = {
        "alerts-only":      ('attributes.status = "ALERT"',           "ALERTS"),
        "temperature-only": ('attributes.event_type = "temperature"', "TEMPERATURE"),
        "all-events":       (None,                                     "ALL"),
    }

    sub_paths = {}
    for name, (expr, _) in subs.items():
        sub_paths[name] = setup_subscription(
            subscriber, project_id, topic_path,
            f"filter-{name}-sub", filter_expr=expr
        )
    print()

    events = []
    types  = ["temperature", "humidity", "pressure", "vibration"]
    for _ in range(msg_count):
        e = generate_event(event_type=random.choice(types))
        events.append(e)

    ok = publish_messages_no_order(publisher, topic_path, events)
    alert_count = sum(1 for e in events if e["status"] == "ALERT")
    temp_count  = sum(1 for e in events if e["event_type"] == "temperature")
    print(f"\n  [producer] Published {ok} messages "
          f"({alert_count} ALERTs, {temp_count} temperature events)\n")
    time.sleep(1)

    lock   = threading.Lock()
    totals = {name: {"count": 0} for name in subs}

    threads = []
    for name, (_, label) in subs.items():
        cb = make_callback(label, totals[name], lock)
        t  = threading.Thread(
            target=stream_subscription,
            args=(subscriber, sub_paths[name], cb, 10),
            daemon=True,
        )
        threads.append(t)

    print("  Starting filtered consumers...\n")
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    print(f"\n{'─'*60}")
    print("  RESULTS:")
    print(f"    All events published:       {msg_count}")
    print(f"    Received by 'all-events':   {totals['all-events']['count']}")
    print(f"    Received by 'alerts-only':  {totals['alerts-only']['count']}  "
          f"(expected ~{alert_count})")
    print(f"    Received by 'temp-only':    {totals['temperature-only']['count']}  "
          f"(expected ~{temp_count})")
    print(f"{'─'*60}\n")

def main():
    os.environ["PUBSUB_EMULATOR_HOST"] = EMULATOR_HOST
    project_id = "demo-project"
    msg_count = 20
    demo_filtering(project_id, msg_count)

if __name__ == "__main__":
    main()
