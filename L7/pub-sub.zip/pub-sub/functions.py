import os
import sys
import json
import time
import random
import uuid
import argparse
import threading
from datetime import datetime, timezone
from concurrent.futures import TimeoutError
from google.cloud import pubsub_v1
from google.api_core.exceptions import AlreadyExists
from google.cloud import pubsub_v1
from google.api_core.exceptions import AlreadyExists
from faker import Faker
fake = Faker()


def generate_event(event_type: str = None) -> dict:
    types = ["temperature", "humidity", "pressure", "vibration"]
    return {
        "event_id":   str(fake.uuid4()),
        "timestamp":  datetime.now(timezone.utc).isoformat(),
        "sensor_id":  f"sensor-{fake.bothify('??###')}",
        "location":   fake.city(),
        "event_type": event_type or fake.random_element(types),
        "value":      round(fake.pyfloat(min_value=0, max_value=100), 2),
        "status":     fake.random_element(["OK", "OK", "OK", "WARN", "ALERT"]),
    }


def make_publisher():
    return pubsub_v1.PublisherClient(
        batch_settings=pubsub_v1.types.BatchSettings(
            max_messages=50, max_bytes=512 * 1024, max_latency=0.05
        )
    )

def make_publisher_ordering(enable_ordering=False):
    return pubsub_v1.PublisherClient(
        batch_settings=pubsub_v1.types.BatchSettings(
            max_messages=50, max_bytes=512 * 1024, max_latency=0.05
        ),
        publisher_options=pubsub_v1.types.PublisherOptions(
            enable_message_ordering=enable_ordering,
        )
    )


def setup_topic(publisher, project_id, topic_name):
    topic_path = publisher.topic_path(project_id, topic_name)
    try:
        publisher.create_topic(request={"name": topic_path})
        print(f"  [setup] Created topic: {topic_path}")
    except AlreadyExists:
        print(f"  [setup] Topic exists:  {topic_path}")
    return topic_path


def setup_subscription(subscriber, project_id, topic_path, sub_name,
                        filter_expr=None, enable_ordering=False):
    sub_path = subscriber.subscription_path(project_id, sub_name)
    req = {"name": sub_path, "topic": topic_path, "ack_deadline_seconds": 30}
    if filter_expr:
        req["filter"] = filter_expr
    if enable_ordering:
        req["enable_message_ordering"] = True
    try:
        subscriber.create_subscription(request=req)
        label = f" [filter: {filter_expr}]" if filter_expr else ""
        print(f"  [setup] Created subscription: {sub_path}{label}")
    except AlreadyExists:
        print(f"  [setup] Subscription exists:  {sub_path}")
    return sub_path


def publish_messages(publisher, topic_path, events: list):
    futures = []
    for event in events:
        payload = json.dumps(event).encode("utf-8")
        f = publisher.publish(
            topic_path,
            data       = payload,
            sensor_id  = event["sensor_id"],
            event_type = event["event_type"],
            status     = event["status"],
            ordering_key = event["sensor_id"],
        )
        futures.append(f)

    ok = 0
    for f in futures:
        try:
            f.result(timeout=10)
            ok += 1
        except Exception as e:
            print(f"  [publish] ERROR: {e}")
    return ok

def publish_messages_no_order(publisher, topic_path, events: list):
    futures = []
    for event in events:
        payload = json.dumps(event).encode("utf-8")
        f = publisher.publish(
            topic_path,
            data       = payload,
            sensor_id  = event["sensor_id"],
            event_type = event["event_type"],
            status     = event["status"],
        )
        futures.append(f)

    ok = 0
    for f in futures:
        try:
            f.result(timeout=10)
            ok += 1
        except Exception as e:
            print(f"  [publish] ERROR: {e}")
    return ok


def make_callback(worker_name: str, counter: dict, lock: threading.Lock,
                  slow: bool = False):
    def callback(message):
        try:
            event = json.loads(message.data.decode("utf-8"))
            with lock:
                counter["count"] += 1
                n = counter["count"]
            print(
                f"  [{worker_name}] #{n:03d} | "
                f"sensor={event['sensor_id']} | "
                f"type={event['event_type']} | "
                f"value={event['value']} | "
                f"status={event['status']}"
            )
            if slow:
                time.sleep(0.3)
            message.ack()
        except Exception as e:
            print(f"  [{worker_name}] ERROR: {e}")
            message.nack()
    return callback


def stream_subscription(subscriber, sub_path, callback,
                         duration: int = 10, label: str = ""):
    flow = pubsub_v1.types.FlowControl(max_messages=5)
    future = subscriber.subscribe(sub_path, callback=callback,
                                  flow_control=flow)
    try:
        future.result(timeout=duration)
    except TimeoutError:
        future.cancel()
        future.result()
    except KeyboardInterrupt:
        future.cancel()

def run_with_emulator(pattern: str, msg_count: int):
    os.environ["PUBSUB_EMULATOR_HOST"] = EMULATOR_HOST
    project_id = "demo-project"
    run_pattern(pattern, project_id, msg_count)


def run_pattern(pattern: str, project_id: str, msg_count: int):
    if pattern == "competing_consumers":
        demo_competing_consumers(project_id, msg_count)
    elif pattern == "broadcast":
        demo_broadcast(project_id, msg_count)
    elif pattern == "ordering":
        demo_ordering(project_id)
    elif pattern == "filtering":
        demo_filtering(project_id, msg_count)
    else:
        print(f"Unknown pattern: {pattern}")
