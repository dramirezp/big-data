resource "google_pubsub_topic" "competing_demo" {
  name                       = "competing-demo"
  message_retention_duration = "600s"
  labels                     = { pattern = "competing-consumers" }
}


resource "google_pubsub_subscription" "competing_sub" {
  name  = "competing-demo-sub"
  topic = google_pubsub_topic.competing_demo.name

  ack_deadline_seconds = 30

  retry_policy {
    minimum_backoff = "5s"
    maximum_backoff = "60s"
  }

  dead_letter_policy {
    dead_letter_topic     = google_pubsub_topic.dead_letter.id
    max_delivery_attempts = 5
  }
}



resource "google_pubsub_topic" "broadcast_demo" {
  name                       = "broadcast-demo"
  message_retention_duration = "600s"
  labels                     = { pattern = "broadcast" }
}

resource "google_pubsub_subscription" "broadcast_analytics" {
  name                 = "broadcast-analytics-sub"
  topic                = google_pubsub_topic.broadcast_demo.name
  ack_deadline_seconds = 30
}

resource "google_pubsub_subscription" "broadcast_alerting" {
  name                 = "broadcast-alerting-sub"
  topic                = google_pubsub_topic.broadcast_demo.name
  ack_deadline_seconds = 30
}

resource "google_pubsub_subscription" "broadcast_storage" {
  name                 = "broadcast-storage-sub"
  topic                = google_pubsub_topic.broadcast_demo.name
  ack_deadline_seconds = 30
}

###############################################################################

resource "google_pubsub_topic" "ordering_demo" {
  name                       = "ordering-demo"
  message_retention_duration = "600s"
  labels                     = { pattern = "ordering" }
}

resource "google_pubsub_subscription" "ordering_sub" {
  name                    = "ordering-demo-sub"
  topic                   = google_pubsub_topic.ordering_demo.name
  enable_message_ordering = true
  ack_deadline_seconds    = 30
}


###############################################################################


resource "google_pubsub_topic" "filter_demo" {
  name                       = "filter-demo"
  message_retention_duration = "600s"
  labels                     = { pattern = "filtering" }
}

resource "google_pubsub_subscription" "filter_alerts" {
  name   = "filter-alerts-only-sub"
  topic  = google_pubsub_topic.filter_demo.name
  filter = "attributes.status = \"ALERT\""

  ack_deadline_seconds = 30
}

resource "google_pubsub_subscription" "filter_temperature" {
  name   = "filter-temperature-only-sub"
  topic  = google_pubsub_topic.filter_demo.name
  filter = "attributes.event_type = \"temperature\""

  ack_deadline_seconds = 30
}

resource "google_pubsub_subscription" "filter_all" {
  name                 = "filter-all-events-sub"
  topic                = google_pubsub_topic.filter_demo.name
  ack_deadline_seconds = 30
}

###############################################################################

resource "google_pubsub_topic" "dead_letter" {
  name   = "dead-letter"
  labels = { purpose = "dead-letter" }
}

resource "google_pubsub_subscription" "dead_letter_sub" {
  name                 = "dead-letter-sub"
  topic                = google_pubsub_topic.dead_letter.name
  ack_deadline_seconds = 60
}