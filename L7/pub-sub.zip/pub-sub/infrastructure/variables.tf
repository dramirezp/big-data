variable "project_id" {
  description = "Your GCP Project ID"
  type        = string
  default     = "my-bigdata-project"
}

variable "region" {
  description = "GCP region"
  type        = string
  default     = "us-central1"
}