import os
import sys
import json
import time
import random
import uuid
import argparse
import threading
from datetime import datetime, timezone
from concurrent.futures import TimeoutError
from functions import *
from google.cloud import pubsub_v1
from google.api_core.exceptions import AlreadyExists
from google.cloud import pubsub_v1
from google.api_core.exceptions import AlreadyExists
from faker import Faker

PROJECT_ID    = "my-bigdata-project" 
TOPIC_NAME    = "bigdata-demo"
EMULATOR_HOST = "localhost:8085"

def demo_ordering(project_id: str):
    print(f"\n{'═'*60}")
    print("  PATTERN 3: ORDERING KEYS")
    print(f"{'═'*60}")

    publisher  = make_publisher_ordering(enable_ordering=True)
    subscriber = pubsub_v1.SubscriberClient()

    topic_path = setup_topic(publisher, project_id, "ordering-demo")
    sub_path   = setup_subscription(
        subscriber, project_id, topic_path,
        "ordering-demo-sub", enable_ordering=True
    )

    sensors = ["sensor-AAA", "sensor-BBB", "sensor-CCC"]
    print("  [producer] Publishing events in sequence per sensor:")
    futures = []
    for seq in range(1, 6):
        for sensor in sensors:
            event = {
                "sensor_id":  sensor,
                "seq":        seq,
                "value":      round(random.uniform(20, 80), 1),
                "timestamp":  datetime.now(timezone.utc).isoformat(),
            }
            payload = json.dumps(event).encode("utf-8")
            f = publisher.publish(
                topic_path,
                data         = payload,
                ordering_key = sensor,
                sensor_id    = sensor,
                event_type   = "temperature",
                status       = "OK",
            )
            futures.append((f, sensor, seq))
            print(f"    Published: {sensor} seq={seq}")
        time.sleep(0.1)

    for f, sensor, seq in futures:
        f.result(timeout=10)


    lock    = threading.Lock()
    counter = {"count": 0}
    seen    = {}

    def ordered_callback(message):
        event = json.loads(message.data.decode("utf-8"))
        sensor = event["sensor_id"]
        seq    = event["seq"]
        with lock:
            counter["count"] += 1
            last = seen.get(sensor, 0)
            ok   = "OK ORDER" if seq == last + 1 else "NO ORDER"
            seen[sensor] = seq
            print(f"  [{sensor}] seq={seq}  {ok}")
        message.ack()

    stream_subscription(subscriber, sub_path, ordered_callback, duration=10)

    print(f"\n  Total received: {counter['count']}")

def main():
    os.environ["PUBSUB_EMULATOR_HOST"] = EMULATOR_HOST
    project_id = "demo-project"
    msg_count = 20
    demo_ordering(project_id)

if __name__ == "__main__":
    main()
